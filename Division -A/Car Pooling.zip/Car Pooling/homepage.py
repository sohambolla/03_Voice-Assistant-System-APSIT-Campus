from tkinter import*
from tkinter import ttk,messagebox
from PIL import Image,ImageTk
import pymysql


class Homepage():
    def __init__(self,root):
        self.root=root
        self.root.title("Login Form")
        self.root.geometry("1550x800+0+0")
        self.root.config(bg="white")

        

        img1=Image.open(r"images\hp.jpg")
        img1=img1.resize((1550,800))
        self.photoimg1=ImageTk.PhotoImage(img1)

        lblimg=Label(self.root,image=self.photoimg1,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=1550,height=800)

        frame1=Frame(self.root,bg="lightblue")
        frame1.place(x=500,y=50,width=600,height=500)

        btn_car=Button(frame1,text="Book Your Car",command=self.car,font=("times new roman",20,"bold"),bg="white",fg="black",cursor="hand2").place(x=200,y=100,width=200,height=40)
        
        btn_payment=Button(frame1,text="Payment",command=self.pay,font=("times new roman",20,"bold"),bg="white",fg="black",cursor="hand2").place(x=200,y=200,width=200,height=40)

        btn_logout=Button(frame1,text="Logout",command=self.Logout,font=("times new roman",20,"bold"),bg="#B00857",fg="lightgray",cursor="hand2").place(x=230,y=374,width=150,height=40)


    def Logout(self):
        self.root.destroy()
        import Login

    def pay(self):
        self.root.destroy()
        import payment

    def car(self):
        self.root.destroy()
        import customer



root=Tk()
obj=Homepage(root)     
root.mainloop()
