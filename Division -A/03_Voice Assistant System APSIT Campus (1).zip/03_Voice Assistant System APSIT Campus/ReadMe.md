(1)Voice Assistant System APSIT Campus (Topic)
(2)Soham Shailendra Bolla
   Sakshi Haridas Ahire
   Sakshi Satish Gaikwad
   Disha Suresh Panchal
(3)A voice assistant is a digital assistant that uses voice recognition, language processing algorithms, and voice synthesis to listen to specific voice commands and return relevant information 
   or perform specific functions as requested by the user.
   Main objective of building personal assistant software (a virtual assistant) is using semantic data sources available on the web. user generated content and providing knowledge from knowledge
   databases.
 