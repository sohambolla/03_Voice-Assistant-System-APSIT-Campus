from cgitb import text
from dis import COMPILER_FLAG_NAMES
from distutils.log import info
from fileinput import close
from importlib.resources import contents
from msilib.schema import Billboard, ComboBox, RadioButton
from operator import contains, itemgetter
#from msilib.schema import ComboBox, Error
from pickletools import uint1
from random import sample
from re import I, L, X
import sys
from telnetlib import X3PAD
from tkinter.ttk import Combobox
#Sfrom tkinter import Widget
from turtle import title
from typing import ItemsView
from unicodedata import category
from PyQt5 import QtWidgets
from PyQt5 import QtWidgets 
from PyQt5.QtWidgets import*
from PyQt5.QtWidgets import QDialog, QApplication
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.uic import loadUi
import sqlite3 
from tkinter import messagebox


# import sqlite3 

# from tkinter import messagebox
# conn = sqlite3.connect('users.db')


# c = conn.cursor()


# c.execute("""CREATE TABLE info (
#     name text,
#     emailId text,
#     phoneno integer,
#     username text,
#     password text,
#     address text
      
# )""")


# conn.commit()
# conn.close()
# root.mainloop()








class welcome(QMainWindow):
    def __init__(self):
        super(welcome,self).__init__()
        loadUi("welcome.ui",self)
        self.B1.clicked.connect(self.login)
        self.B2.clicked.connect(self.register)
        


    # def search(self):
    #     s1.close()
    #     s12.show()    

    def login(self):
        s1.close() 
        s2.show() 

    def register(self):  
        s1.close()
        s3.show()

    
class login(QMainWindow):
    def __init__(self):
        super(login,self).__init__()
        loadUi("login.ui",self)
        self.B1.clicked.connect(self.login2)
        self.B2.clicked.connect(self.reg)
        self.B3.clicked.connect(self.back1)
       

    def login2(self):
        # s2.close()
        # s1.show()

    
        username = self.lineEdit_4.text()
        password = self.lineEdit_5.text()
        if username=='' or password=='':
            messagebox.showerror('Error', 'Feilds cannot be empty!')
        else:
            conn = sqlite3.connect('users.db')
            cursor = conn.execute('SELECT * from info where username="%s" and password="%s"'%(username,password))
            if cursor.fetchone():
                messagebox.showinfo('Login Status', 'Logged in Successfully!')

                s2.close()
                s4.show()
            else:
                messagebox.showerror('Login Status', 'invalid username or password')
    
                 
        
             
    
    def back1(self):
        s2.close()
        s1.show() 

    def reg(self):
        s2.close()
        s3.show()



class Hotel(QMainWindow):
    def __init__(self):
        super(Hotel,self).__init__()
        loadUi("HOTELL.ui",self)
        self.B1.clicked.connect(self.mau)
        self.B2.clicked.connect(self.mini)
        self.B3.clicked.connect(self.mumma)
        self.B4.clicked.connect(self.burger)
        # self.B4.clicked.connect(self)

    def mau(self):
        s4.close()
        s6.show()

    def mini(self):
        s4.close()
        s5.show()

    def mumma(self):
        s4.close()
        s11.show()

    def burger(self):
        s4.close()
        s12.show()        


                   

class register(QMainWindow):
    def __init__(self):
        super(register,self).__init__()
        loadUi("register.ui",self)
        self.B1.clicked.connect(self.signup1)
        self.B2.clicked.connect(self.back2)
    def signup1(self):
        # s3.close()
        # s2.show()
    
        name=self.lineEdit_1.text()
        emailid=self.lineEdit_2.text()
        phone=self.lineEdit_3.text()
        username=self.lineEdit_4.text()
        password=self.lineEdit_5.text()
        address=self.lineEdit_6.text()
        check_counter=0
        warn = ""

        if name == "":
            warn = "Name can't be empty"

        else:
            check_counter += 1
        if emailid == "":
            warn = "Emailid can't be empty"
        else:
             check_counter +=1
        if  emailid.__contains__("@gmail.com"):
            check_counter +=1
            warn = "email id is invalid"
        
        else:
            check_counter +=1                     
            
        if phone == "":
            warn = "Phoneno can't be empty"
        else:
            check_counter+=1
        if username =="":
            warn ="Username can't be empty"
        else:
            check_counter+=1
        if password == "":
            warn = "password cannot be empty"
        else:
            check_counter += 1
        if address =="":
            warn ="field can't be empty"
        else:
            check_counter += 1
        
        
        if check_counter == 7:
            try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO info VALUES (:name, :emailId, :phoneno, :username, :password, :address)", {
                            'name': name,
                            'emailId': emailid,
                            'phoneno': phone,
                            'username': username,
                            'password': password,
                            'address': address
                            
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'Registered Successfully')

                s3.close()
                s2.show()
                
                
                

                
            except Exception as ep:
                messagebox.showerror('', ep) 
        else:
            messagebox.showerror('Error', warn)
            

        
        

    def back2(self):
        s3.close()
        s1.show()  





 

# class nf(QMainWindow):
#     def __init__(self):
#         super(nf,self).__init__()
#         loadUi("hotel.ui",self)       
#         self.B1.clicked.connect(self.enter)
#         self.CM1 = QtWidgets.QComboBox(self.centralwidget)
#         self.CM1.setGeometry(QtCore.QRect(310, 270, 441, 51))
#         self.CM1.setStyleSheet("background-color: rgb(255, 255, 127);\n"
# "font: 75 12pt \"Showcard Gothic\";")
#         self.CM1.setEditable(False)
#         self.CM1.setCurrentText("")
#         self.CM1.setObjectName("CM1")
#         self.CM1.addItem("mau restuarant")
#         self.CM1.addItem("minidhaba")
#         self.CM1.addItem("shree hotel")
#         self.CM1.currentTextChanged.connect(self.enter)
#         # self.pushButton_10.clicked.connect(self.enter)
#         # self.pushButton.clicked.connect(self.back2)

#     def enter(self):
#         CM1=self.CM1.currentTextChanged("mau restarant")
#         print(CM1)
        
    
        


            




   

        
       
       
       
        

    




    



     



class payment(QMainWindow):
    def __init__(self):
        super(payment,self).__init__()
        loadUi("paymentpage.ui",self)
        
        # self.B2.clicked.connect(self.credit)
        self.B3.clicked.connect(self.cash)
        self.B4.clicked.connect(self.back)

     

    # def credit(self):
    #     s9.close()
    #     s8.show()    

    def cash(self):
        s9.close()
        s10.show() 
    def back(self):
        s9.close
        s2.show()    
        





         

    
        


class reviw(QMainWindow):
    def __init__(self):
        super(reviw,self).__init__()
        loadUi("review.ui",self)
        self.radioButton.toggled.connect(lambda:self.btnstate(self.radioButton))
        self.radioButton.toggled.connect(lambda:self.btnstate(self.radioButton_2))
        self.radioButton.toggled.connect(lambda:self.btnstate(self.radioButton_3))
        self.B1.clicked.connect(self.submit)


    def submit(self):
        feedback=self.lineEdit.text()


        try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO sample VALUES (:feedback)", {
                            'feedback': feedback,
                           
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'reviwed Successfully')


        except Exception as ep:
                messagebox.showerror('', ep) 
                


   




    
   

    def btnstate(self,b):
            if b.isChecked():
                    self.label_2.setText(b.text())  



class r2(QMainWindow):
    def __init__(self):
        super(r2,self).__init__()
        loadUi("review.ui",self)
        self.radioButton.toggled.connect(lambda:self.btnstate(self.radioButton))
        self.radioButton.toggled.connect(lambda:self.btnstate(self.radioButton_2))
        self.radioButton.toggled.connect(lambda:self.btnstate(self.radioButton_3))
        self.B1.clicked.connect(self.submit)


    def submit(self):
        feedback=self.lineEdit.text()


        try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO sample VALUES (:feedback)", {
                            'feedback': feedback,
                           
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'reviwed Successfully')

                s10.close()


        except Exception as ep:
                messagebox.showerror('', ep) 



    def btnstate(self,b):
            if b.isChecked():
                    self.label_3.setText(b.text())            
                

    


class H2(QMainWindow):
    def __init__(self):
        super(H2,self).__init__()
        loadUi("mau Re.ui",self)
        
        self.B2.clicked.connect(self.order)

        self.B1.clicked.connect(self.clean)
        self.B3.clicked.connect(self.P1)
        self.B4.clicked.connect(self.back)
        # self.B5.clicked.connect(self.btnstate)
    def order(self):
        total = 0
        I1 = 0
        # I= 0
        # I = 0
        # I4 = 0
        # I5 = 0
        # I6 = 0
        # I7 = 0
        # I8 = 0
        # I9 = 0
        # I10 = 0

        if(self.C1.isChecked() == True):
            I1 = int(self.S1.text())
            total = total + (I1 * 250)
        if(self.C2.isChecked() == True):
            I1 = int(self.S2.text())
            total = total + (I1 * 300)
        if(self.C3.isChecked() == True):    
            I1 = int(self.S3.text())
            total = total + (I1 * 170)
        if(self.C4.isChecked() == True):
            I1 = int(self.S4.text())
            total = total + (I1 * 120)
        if(self.C5.isChecked() == True):    
            I1 = int(self.S5.text())
            total = total + (I1 * 250)
        if(self.C6.isChecked() == True):    
            I1 = int(self.S6.text())
            total = total + (I1 * 200)
        if(self.C7.isChecked() == True):    
            I1 = int(self.S7.text())
            total = total + (I1 * 120)
        if(self.C8.isChecked() == True):    
            I1 = int(self.S8.text())
            total = total + (I1 * 250)
        if(self.C9.isChecked() == True):    
            I1 = int(self.S9.text())
            total = total + (I1 * 250)
        if(self.C10.isChecked() == True):    
            I1 = int(self.S10.text())
            total = total + (I1 * 200)
        self.T2.setText(str(total))
        if self.C1.isChecked()==True:
            x="CHICKEN TANDOORI"
            x2=int(self.S1.text())
        if self.C2.isChecked()==True:
            x="CHICKEN FRY"
            x2=int(self.S2.text())
        if self.C3.isChecked()==True:
            x="SHORMA"
            x2=int(self.S3.text())
        if self.C4.isChecked()==True:
            x="CHICKEN RICE"
            x2=int(self.S4.text())
        if self.C5.isChecked()==True:
            x="CHICKEN HANDI"
            x2=int(self.S5.text())
        if self.C6.isChecked()==True:
            x="CHICKEN CRISPY"
            x2=int(self.S6.text())
        if self.C7.isChecked()==True:
            x="CHICKEN SHEZWAN RICE"
            x2=int(self.S7.text())
        if self.C8.isChecked()==True:
            x="CHICKEN TRIPPLE RICE"
            x2=int(self.S8.text())
        if self.C9.isChecked()==True:
            x="CHICKEN LOLLYPOP"
            x2=int(self.S9.text())
        if self.C10.isChecked()==True:
            x="CHICKEN FRIED RICE"
            x2=int(self.S10.text())
        item=x
        quantity=I1
        total=int(self.T2.text())

        try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO mau VALUES (:FoodItem, :QTY, :TotalBill )", {
                             'FoodItem': item,
                             'QTY': quantity,
                            'TotalBill': total,
                            
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'Ordered recieved')
        except Exception as ep:
                messagebox.showerror('', ep)

   

        
    
    def clean(self):
        self.C1.setChecked(False)
        self.C2.setChecked(False)
        self.C3.setChecked(False)
        self.C4.setChecked(False)
        self.C5.setChecked(False)
        self.C6.setChecked(False)
        self.C7.setChecked(False)
        self.C8.setChecked(False)
        self.C9.setChecked(False)
        self.C10.setChecked(False)
        # self.lebel_3.setChecked(False)
        self.S1.setValue(0)
        self.S2.setValue(0)
        self.S3.setValue(0)
        self.S4.setValue(0)
        self.S5.setValue(0)
        self.S6.setValue(0)
        self.S7.setValue(0)
        self.S8.setValue(0)
        self.S9.setValue(0)
        self.S10.setValue(0)
        # self.T2.setvalue(0)

            
                
                

    

       

        
    def P1(self):

        s5.close()
        s9.show() 

       

    def back(self):
        s5.close()
        s4.show()       


    


class H3(QMainWindow):
    def __init__(self):
        super(H3,self).__init__()
        loadUi("minidhaba.ui",self)
        
        self.B2.clicked.connect(self.order_2)
        self.B1.clicked.connect(self.clean_2)  
        self.B3.clicked.connect(self.P2)
        self.B4.clicked.connect(self.back)

    def order_2(self):
        total = 0
        I1 = 0
        I2 = 0
        I3 = 0
        I4 = 0
        I5 = 0
        I6 = 0
        I7 = 0
        I8 = 0
        I9 = 0
        I10 = 0
        I11 = 0
        I12 = 0
        I13 = 0
        I14 = 0
        I15 = 0
        I16 = 0


        if(self.C1.isChecked() == True):
            I1 = int(self.S1.text())
            total = total + (I1 * 40)
        if(self.C2.isChecked() == True):
            I2 = int(self.S2.text())
            total = total + (I2 * 70)
        if(self.C3.isChecked() == True):    
            I3 = int(self.S3.text())
            total = total + (I3 * 100)
        if(self.C4.isChecked() == True):
            I4 = int(self.S4.text())
            total = total + (I4 * 120)
        if(self.C5.isChecked() == True):    
            I5 = int(self.S5.text())
            total = total + (I5 * 8)
        if(self.C6.isChecked() == True):    
            I6 = int(self.S6.text())
            total = total + (I6 * 25)
        if(self.C7.isChecked() == True):    
            I7 = int(self.S7.text())
            total = total + (I7 * 15)
        if(self.C8.isChecked() == True):    
            I8 = int(self.S8.text())
            total = total + (I8 * 20)
        if(self.C9.isChecked() == True):    
            I9 = int(self.S9.text())
            total = total + (I9 * 50)
        if(self.C10.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I10 * 130)
        if(self.C11.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I11 * 110)
        if(self.C12.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I12 * 130)
        if(self.C13.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I13 * 100)
        if(self.C14.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I14 * 140)
        if(self.C15.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I15 * 80)
        if(self.C16.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I16 * 90)
        self.T2.setText(str(total)) 

           

        if self.C1.isChecked()==True:
            x="NAAN"
            x2=int(self.S1.text())
        if self.C2.isChecked()==True:
            x="JEERA RICE "
            x2=int(self.S2.text())
        if self.C3.isChecked()==True:
            x="PANEER PULAV"
            x2=int(self.S3.text())
        if self.C4.isChecked()==True:
            x="KAHSMIRI PULAV"
            I4=int(self.S4.text())
        if self.C5.isChecked()==True:
            x="ROTI"
            I5=int(self.S5.text())
        if self.C6.isChecked()==True:
            x="BUTTER NAAN"
            x2=int(self.S6.text())
        if self.C7.isChecked()==True:
            x="BUTTER ROTI"
            x2=int(self.S7.text())
        if self.C8.isChecked()==True:
            x="STUF NAAN"
            x2=int(self.S8.text())
        if self.C9.isChecked()==True:
            x="PLAIN RICE"
            x2=int(self.S9.text())
        if self.C10.isChecked()==True:
            x="HANDI BIRAYANI"
            x2=int(self.S10.text())
        if self.C11.isChecked()==True:
            x="HAIDRABADI BIRYANI"
            x2=int(self.S11.text())
        if self.C12.isChecked()==True:
            x="CHEESE BIRANI"
            x2=int(self.S12.text())
        if self.C13.isChecked()==True:
            x="VEG BIRYANI"
            x2=int(self.S13.text())
        if self.C14.isChecked()==True:
            x="PANJABI THALI"
            x2=int(self.S14.text())
        if self.C15.isChecked()==True:
            x="SADHA THALI"
            x2=int(self.S15.text())
        if self.C16.isChecked()==True:
            x="SADHA THALI(PARATHA)"
            x2=int(self.S16.text())        
        item=x
        quantity=x2
        total=int(self.T2.text()) 


        try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO mini VALUES (:FoodItem, :QTY, :TotalBill  )", {
                             'FoodItem':item,
                             'QTY': quantity,
                            'TotalBill': total,
                            
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'Ordered Recieved')
        except Exception as ep:
                messagebox.showerror('', ep)
   

        
    def clean_2(self):
        self.C1.setChecked(False)
        self.C2.setChecked(False)
        self.C3.setChecked(False)
        self.C4.setChecked(False)
        self.C5.setChecked(False)
        self.C6.setChecked(False)
        self.C7.setChecked(False)
        self.C8.setChecked(False)
        self.C9.setChecked(False)
        self.C10.setChecked(False)
        self.C11.setChecked(False)
        self.C12.setChecked(False)
        self.C13.setChecked(False)
        self.C14.setChecked(False)
        self.C15.setChecked(False)
        self.C16.setChecked(False)
        #self.lebel_3.setChecked(False)
        self.S1.setValue(0)
        self.S2.setValue(0)
        self.S3.setValue(0)
        self.S4.setValue(0)
        self.S5.setValue(0)
        self.S6.setValue(0)
        self.S7.setValue(0)
        self.S8.setValue(0)
        self.S9.setValue(0)
        self.S10.setValue(0)
        self.S11.setValue(0)
        self.S12.setValue(0)
        self.S13.setValue(0)
        self.S14.setValue(0)
        self.S15.setValue(0)
        self.S16.setValue(0)

    def P2(self):
        s6.close()
        s9.show()    

    def back(self):
        s6.close()
        s4.show()   



class H4(QMainWindow):
    def __init__(self):
        super(H4,self).__init__()
        loadUi("MUM.ui",self)

        self.B2.clicked.connect(self.R1)
        self.B1.clicked.connect(self.o1)
        self.B3.clicked.connect(self.P3)
        self.B4.clicked.connect(self.P4)

    def P3(self):
        s11.close()
        s9.show()  

    def P4(self):
        s11.close()
        s4.show()        



    def o1(self):
        total = 0
        I1 = 0
        I2 = 0
        I3 = 0
        I4 = 0
        I5 = 0
        I6 = 0
        I7 = 0
        I8 = 0
        I9 = 0
        I10 = 0
        I11 = 0
        I12 = 0
        I13 = 0
        I14 = 0
        I15 = 0

        if(self.C1.isChecked() == True):
            I1 = int(self.S1.text())
            total = total + (I1 * 40)
        if(self.C2.isChecked() == True):
            I2 = int(self.S2.text())
            total = total + (I2 * 70)
        if(self.C3.isChecked() == True):    
            I3 = int(self.S3.text())
            total = total + (I3 * 100)
        if(self.C4.isChecked() == True):
            I4 = int(self.S4.text())
            total = total + (I4 * 120)
        if(self.C5.isChecked() == True):    
            I5 = int(self.S5.text())
            total = total + (I5 * 8)
        if(self.C6.isChecked() == True):    
            I6 = int(self.S6.text())
            total = total + (I6 * 25)
        if(self.C7.isChecked() == True):    
            I7 = int(self.S7.text())
            total = total + (I7 * 15)
        if(self.C8.isChecked() == True):    
            I8 = int(self.S8.text())
            total = total + (I8 * 20)
        if(self.C9.isChecked() == True):    
            I9 = int(self.S9.text())
            total = total + (I9 * 50)
        if(self.C10.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I10 * 130)
        if(self.C11.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I11 * 110)
        if(self.C12.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I12 * 130)
        if(self.C13.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I13 * 100)
        if(self.C14.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I14 * 140)
        if(self.C15.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I15 * 80)
        
        self.T2.setText(str(total))

        
        if self.C1.isChecked()==True:
            x="SCHEZWAN FRIED RICE"
            x2=int(self.S1.text())
        if self.C2.isChecked()==True:
            x="PANEER MANCHURIAN RICE"
            x2=int(self.S2.text())
        if self.C3.isChecked()==True:
            x="HAKKA NOODLES"
            x2=int(self.S3.text())
        if self.C4.isChecked()==True:
            x="LEMON CHICKEN"
            I4=int(self.S4.text())
        if self.C5.isChecked()==True:
            x="CHOP SUEY"
            I5=int(self.S5.text())
        if self.C6.isChecked()==True:
            x="PANEER FRIED RICE"
            x2=int(self.S6.text())
        if self.C7.isChecked()==True:
            x="CHILLI PANEER"
            x2=int(self.S7.text())
        if self.C8.isChecked()==True:
            x="SCHEZWAN CHICKEN"
            x2=int(self.S8.text())
        if self.C9.isChecked()==True:
            x="CHICKEN LOLLYPOP"
            x2=int(self.S9.text())
        if self.C10.isChecked()==True:
            x="SCHEZWAN NOODLES"
            x2=int(self.S10.text())
        if self.C11.isChecked()==True:
            x="CHILLY CHICKEN"
            x2=int(self.S11.text())
        if self.C12.isChecked()==True:
            x="CHOWMEIN"
            x2=int(self.S12.text()) 
        if self.C13.isChecked()==True:
            x="GARLIC CHICKEN"
            x2=int(self.S13.text())
        if self.C14.isChecked()==True:
            x="VEG SPRING ROLLS"
            x2=int(self.S10.text())
        if self.C15.isChecked()==True:
            x="HUNAN CHICKEN"
            x2=int(self.S15.text())                   
        item=x
        quantity=x2
        total=int(self.T2.text()) 


        try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO mumma VALUES (:FoodItem, :QTY, :TotalBill )", {
                            'FoodItem': item ,
                            'QTY': quantity,
                            'TotalBill': total,
                            
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'Ordered Received')
        except Exception as ep:
                messagebox.showerror('', ep)


    def R1(self):
         self.C1.setChecked(False)
         self.C2.setChecked(False)
         self.C3.setChecked(False)
         self.C4.setChecked(False)
         self.C5.setChecked(False)
         self.C6.setChecked(False)
         self.C7.setChecked(False)
         self.C8.setChecked(False)
         self.C9.setChecked(False)
         self.C10.setChecked(False)
         self.C11.setChecked(False)
         self.C12.setChecked(False)
         self.C13.setChecked(False)
         self.C14.setChecked(False)
         self.C15.setChecked(False)
         
        #self.lebel_3.setChecked(False)
         self.S1.setValue(0)
         self.S2.setValue(0)
         self.S3.setValue(0)
         self.S4.setValue(0)
         self.S5.setValue(0)
         self.S6.setValue(0)
         self.S7.setValue(0)
         self.S8.setValue(0)
         self.S9.setValue(0)
         self.S10.setValue(0)
         self.S11.setValue(0)
         self.S12.setValue(0)
         self.S13.setValue(0)
         self.S14.setValue(0)
         self.S15.setValue(0)


class H5(QMainWindow):
    def __init__(self):
        super(H5,self).__init__()
        loadUi("Burgerr.ui",self)

        self.B2.clicked.connect(self.O2)
        self.B1.clicked.connect(self.R2)
        self.B3.clicked.connect(self.P4)
        self.B4.clicked.connect(self.Back2)

    def P4(self):
        s12.close()
        s9.show()

    


    def O2(self):
        total = 0
        I1 = 0
        I2 = 0
        I3 = 0
        I4 = 0
        I5 = 0
        I6 = 0
        I7 = 0
        I8 = 0
        I9 = 0
        I10 = 0
        I11 = 0
        I12 = 0
        I13 = 0
        I14 = 0
        I15 = 0

        if(self.C1.isChecked() == True):
            I1 = int(self.S1.text())
            total = total + (I1 * 129)
        if(self.C2.isChecked() == True):
            I2 = int(self.S2.text())
            total = total + (I2 * 139)
        if(self.C3.isChecked() == True):    
            I3 = int(self.S3.text())
            total = total + (I3 * 199)
        if(self.C4.isChecked() == True):
            I4 = int(self.S4.text())
            total = total + (I4 * 200)
        if(self.C5.isChecked() == True):    
            I5 = int(self.S5.text())
            total = total + (I5 * 95)
        if(self.C6.isChecked() == True):    
            I6 = int(self.S6.text())
            total = total + (I6 * 159)
        if(self.C7.isChecked() == True):    
            I7 = int(self.S7.text())
            total = total + (I7 * 129)
        if(self.C8.isChecked() == True):    
            I8 = int(self.S8.text())
            total = total + (I8 * 645)
        if(self.C9.isChecked() == True):    
            I9 = int(self.S9.text())
            total = total + (I9 * 428)
        if(self.C10.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I10 * 1445)
        if(self.C11.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I11 * 833)
        if(self.C12.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I12 * 697)
        if(self.C13.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I13 * 565)
        if(self.C14.isChecked() == True):    
            I10 = int(self.S10.text())
            total = total + (I14 * 498)
        
        
        self.T2.setText(str(total))

        
        if self.C1.isChecked()==True:
            x="chicken whopper "
            x2=int(self.S1.text())
        if self.C2.isChecked()==True:
            x="veg whopper"
            x2=int(self.S2.text())
        if self.C3.isChecked()==True:
            x="chicken masala whopper"
            x2=int(self.S3.text())
        if self.C4.isChecked()==True:
            x="crispy chicken burger"
            I4=int(self.S4.text())
        if self.C5.isChecked()==True:
            x="BK veggis"
            I5=int(self.S5.text())
        if self.C6.isChecked()==True:
            x="feiry chicken burgerrs"
            x2=int(self.S6.text())
        if self.C7.isChecked()==True:
            x="Paneer king melt"
            x2=int(self.S7.text())
        if self.C8.isChecked()==True:
            x="2 paneer royal burger + 2med fries(free)"
            x2=int(self.S8.text())
        if self.C9.isChecked()==True:
            x="2 feiry burger+1 large fries(free)"
            x2=int(self.S9.text())
        if self.C10.isChecked()==True:
            x="crispy chicken burger+1pepsi(free)"
            x2=int(self.S10.text())
        if self.C11.isChecked()==True:
            x="2crispy chicken supreme + 2grill + 2fries"
            x2=int(self.S11.text())
        if self.C12.isChecked()==True:
            x="1Chicken tandoor grill+1fiery chicken+2pepsi"
            x2=int(self.S12.text()) 
        if self.C13.isChecked()==True:
            x="2chicken kheema fries+1chicken chilli chees"
            x2=int(self.S13.text())
        if self.C14.isChecked()==True:
            x="king fries +1spicy chiken sticks+2pepsi"
            x2=int(self.S10.text())
                         
        item=x
        quantity=x2
        total=int(self.T2.text()) 


        try:
                con = sqlite3.connect('users.db')
                cur = con.cursor()
                cur.execute("INSERT INTO mumma VALUES (:FoodItem, :QTY, :TotalBill )", {
                            'FoodItem': item ,
                            'QTY': quantity,
                            'TotalBill': total,
                            
                            })
                con.commit()
                messagebox.showinfo('confirmation', 'Ordered Received')
        except Exception as ep:
                messagebox.showerror('', ep)


    def R2(self):
         self.C1.setChecked(False)
         self.C2.setChecked(False)
         self.C3.setChecked(False)
         self.C4.setChecked(False)
         self.C5.setChecked(False)
         self.C6.setChecked(False)
         self.C7.setChecked(False)
         self.C8.setChecked(False)
         self.C9.setChecked(False)
         self.C10.setChecked(False)
         self.C11.setChecked(False)
         self.C12.setChecked(False)
         self.C13.setChecked(False)
         self.C14.setChecked(False)
         
        #self.lebel_3.setChecked(False)
         self.S1.setValue(0)
         self.S2.setValue(0)
         self.S3.setValue(0)
         self.S4.setValue(0)
         self.S5.setValue(0)
         self.S6.setValue(0)
         self.S7.setValue(0)
         self.S8.setValue(0)
         self.S9.setValue(0)
         self.S10.setValue(0)
         self.S11.setValue(0)
         self.S12.setValue(0)
         self.S13.setValue(0)
         self.S14.setValue(0)
        
    def Back2(self):
        s12.close()
        s4.show()


         
        






      
        

# class test(QMainWindow):
#     def __init__(self):
#         super(test,self).__init__()
#         loadUi("test.ui",self)
        
#         self.B2.clicked.connect(self.order)
#         self.B1.clicked.connect(self.clean)

        
                
        
        
        

        

        
       




App=QApplication(sys.argv)
s1=welcome()
s2=login()
s3=register()
s4=Hotel()
s5=H2()
s6=H3()

# s8=credit()
s9=payment()
s10=reviw()
s11=H4()
s12=H5()
s1.show()
App.exec()
