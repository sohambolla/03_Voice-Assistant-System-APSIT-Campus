# ClinicManagmentSystem


# E-Clinic Managment

<br>• CLINIC MANAGEMENT SYSTEM is a project which aims is 
developing a computerized system to maintain all information 
of the Clinic Entities.
<br/>• It has a facility of Admin Login through which the Admin can 
monitor the whole system.
<br/>• Admin Modules are managing patients, manage Doctor’s, and 
manage Appointments
<br/>• Patient Modules are to fill the registration form, Add details, 
find Doctor’s and applied for appointment, view appointment, 
view doctor prescription details.
<br/>• Doctor Modules are to login, view appointments list, view 
patient details.
<br/>• Overall,this project of ours is being developed to help the Clinic 
Administration in the best possible way also reduce the human 
efforts

# Team members
 <br/>Vishnukant Mule
 <br/>Avinash Andhale
 <br/>Prathamesh Naik
 <br/>Jemin Bhanushali
 
 ## Installation

Install my-project with Windows

   <br/>1.Download E-Clinic Managent.Zip 
   <br/>2.When you extract zip file you will get 2 files one
    is system and anothes is database
   <br/>3.In e-clinic database you will get sql file. simply 
    open this file on sql workbench for creating a database
   <br/>4.After creating Database open e-clinic system file 
   <br/>5.In that folder you will found main.py file
   <br/>6.Simply run this python file
  
  # Screenshots
  ![Screenshot 2022-05-03 180129](https://user-images.githubusercontent.com/92650489/166649504-7f91090e-5648-4ebe-8ac9-5b45c728b6c1.jpg)
![Screenshot![Screenshot 2022-05-03 191738](https://user-images.githubusercontent.com/92650489/166649571-6b614404-09a0-42c3-a2b3-aeef8a541753.jpg)
 2022-05-03 181024](https://user-images.githubusercontent.com/92650489/166649534-090f1229-650a-4e36-bb79-20b2aab94c55.jpg)
![Screenshot 2022-05-03 193541]![Screenshot 2022-05-03 180312](https://user-images.githubusercontent.com/92650489/166649632-c74acf87-3503-48aa-8c88-dda57314d3f8.jpg)
(https://user-images.githubusercontent.com/92650489/166649589-7efa3fa8-7388-4596-8a61-76a7679d3551.jpg)
![Screenshot 2022-05-03 180221](https://user-images.githubusercontent.com/92650489/166649677-7c9f952b-4c64-467b-b304-4705c04003d3.jpg)

![Screenshot 2022-05-03 181436](https://user-images.githubusercontent.com/92650489/166649548-c32291c6-3a8b-49d1-bf10-6f599f4cf049.jpg)
![Screenshot 2022-05-03 180252](https://user-images.githubusercontent.com/92650489/166649650-9847ad52-ce21-4ca4-92cb-1cafa6898ca4.jpg)
