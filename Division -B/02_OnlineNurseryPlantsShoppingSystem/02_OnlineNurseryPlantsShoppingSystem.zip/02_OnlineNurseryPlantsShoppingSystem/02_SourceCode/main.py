# Importing required modules
from tkinter import *
from PIL import Image, ImageTk
from tkinter import messagebox
import pymysql
from tkinter import ttk


class Login:

    def __init__(self):

        self.login = root
        self.login.title("Login")
        self.login.geometry('450x500+525+100')
        self.login.resizable(False, False)

        # Creating Canvas
        self.canvas = Canvas(self.login, width=450, height=500, bd=0)
        self.canvas.pack()

        # Adding image to canvas
        self.img = ImageTk.PhotoImage(Image.open("Welcome to E-Nursery.png"))
        self.canvas.create_image(0, 0, anchor=NW, image=self.img)

        # Creating Username label
        lbl1 = Label(self.canvas, text="Username :",
                     bg="light yellow", font=('Helvetica 12 bold italic'))
        lbl1.place(x=70, y=140)

        # Creating Password label
        lbl2 = Label(self.canvas, text="Password :",
                     bg="light yellow", font=('Helvetica 12 bold italic'))
        lbl2.place(x=70, y=200)

        # Using Entry widget to take user input
        self.username1 = Entry(self.canvas, width=30)
        self.username1.place(x=180, y=140, height=25)
        self.password1 = Entry(self.canvas, show="*", width=30)
        self.password1.place(x=180, y=200, height=25)

        # Creating login button
        Btn1 = Button(self.canvas, text="Login", bg="light yellow", fg="black", font=('Helvetica 12 bold italic'),
                      command=self.Login)
        Btn1.place(x=90, y=260)

        # Creating register button
        Btn2 = Button(self.canvas, text="Register", bg="light yellow", fg="black", font=('Helvetica 12 bold italic'),
                      command=self.Registration)
        Btn2.place(x=160, y=260)

        Btn3 = Button(self.canvas, text="Forgot Password?", bg="light yellow", fg="black", font=('Helvetica 12 bold italic'),
                      command=self.forgot_password)
        Btn3.place(x=250, y=260)

    # Login page connection with DB

    def Login(self):

        if self.username1.get() == "" or self.password1.get() == "":
            messagebox.showerror(
                "Error", "All fields are required!", parent=self.login)
        elif self.username1.get() == self.password1.get():
            messagebox.showerror(
                "Error", "Username and Password should not be the same!", parent=self.login)
        else:
            try:
                con = pymysql.connect(
                    host="localhost", user="root", password="kevin1504", database="Nursery")

                cur = con.cursor()
                cur.execute('select * from information where Username=%s and Pass=%s',
                            (self.username1.get(), self.password1.get()))

                row = cur.fetchone()
                if row == None:
                    messagebox.showerror(
                        'Error', 'Invalid Username or Password', parent=self.login)

                else:
                    messagebox.showinfo("Login", "Login Successful!")
                    self.login.destroy()
                    self.Home()

                con.close()

            except Exception as es:
                messagebox.showerror(
                    "Error", f"Error due to: {str(es)}", parent=self.login)

    # Creating function for Registration Form
    def Registration(self):
        self.registration = Toplevel()
        self.registration.title("Registration Form")
        self.registration.geometry('450x500+525+100')
        self.registration.resizable(False, False)

        # Creating canvas for Registration Form
        self.canvas1 = Canvas(self.registration, width=450, height=500, bd=0,)
        self.canvas1.pack()

        # Adding image to canvas1
        self.img1 = ImageTk.PhotoImage(Image.open("Registration.jpg"))
        self.canvas1.create_image(0, 0, anchor=NW, image=self.img1)

        # Creating labels and entries
        fullname = Label(self.canvas1, text="Full Name :",
                         bg="light yellow", font=('Helvetica 12 bold italic'))
        self.fullname1 = Entry(self.canvas1, width=30)
        username = Label(self.canvas1, text="Username :",
                         bg="light yellow", font=('Helvetica 12 bold italic'))
        self.username1 = Entry(self.canvas1, width=30)
        password = Label(self.canvas1, text="Password :",
                         bg="light yellow", font=('Helvetica 12 bold italic'))
        self.password1 = Entry(self.canvas1, show="*", width=30)
        confirmpassword = Label(self.canvas1, text="Confirm Password :", bg="light yellow",
                                font=('Helvetica 12 bold italic'))
        self.confirmpassword1 = Entry(self.canvas1, show="*", width=30)
        city = Label(self.canvas1, text="City :", bg="light yellow",
                     font=('Helvetica 12 bold italic'))
        self.city1 = Entry(self.canvas1, width=30)
        email = Label(self.canvas1, text="Email :",
                      bg="light yellow", font=('Helvetica 12 bold italic'))
        self.email1 = Entry(self.canvas1, width=30)
        phnno = Label(self.canvas1, text="Phone No. :",
                      bg="light yellow", font=('Helvetica 12 bold italic'))
        self.phnno1 = Entry(self.canvas1, width=30)
        security = Label(self.canvas1, text="Security Question :",
                         bg="light yellow", font=('Helvetica 12 bold italic'))
        n = StringVar()
        self.security1 = ttk.Combobox(
            self.canvas1, width=32, textvariable=n, state='readonly')
        self.security1['values'] = (' In what city were you born?',
                                    ' What is your mothers maiden name?',
                                    ' What is the name of your first school? ',
                                    ' What is your astrological sign?')
        security_answer = Label(self.canvas1, text="Security Answer :",
                                bg="light yellow", font=('Helvetica 12 bold italic'))
        self.security_answer1 = Entry(self.canvas1, width=30)

        # Adding labels and entries to canvas1
        fullname.place(x=114, y=30)
        self.fullname1.place(x=220, y=30, height=25)
        username.place(x=112, y=70)
        self.username1.place(x=220, y=70, height=25)
        password.place(x=115, y=110)
        self.password1.place(x=220, y=110, height=25)
        confirmpassword.place(x=50, y=150)
        self.confirmpassword1.place(x=220, y=150, height=25)
        city.place(x=160, y=190)
        self.city1.place(x=220, y=190, height=25)
        email.place(x=148, y=230)
        self.email1.place(x=220, y=230, height=25)
        phnno.place(x=110, y=270)
        self.phnno1.place(x=220, y=270, height=25)
        security.place(x=57, y=310)
        self.security1.place(x=220, y=310, height=25)
        security_answer.place(x=66, y=350)
        self.security_answer1.place(x=220, y=350, height=25)

        # Creating Buttons for Registration Form
        register = Button(self.canvas1, text="Register", bg="light yellow", font=('Helvetica 12 bold italic'),
                          command=self.register_info)
        leave = Button(self.canvas1, text="Go back to Login", bg="light yellow", font=('Helvetica 12 bold italic'),
                       command=lambda: [self.registration.destroy()])

        # Adding Buttons to canvas1
        register.place(x=128, y=450)
        leave.place(x=240, y=450)

        self.registration.mainloop()

    # Registering values into the DB

    def register_info(self):

        if self.fullname1.get() == "" or self.username1.get() == "" or self.password1.get() == "" or self.confirmpassword1.get() == "" or self.city1.get() == "" or self.email1.get() == "" or self.phnno1.get() == "" or self.security1.get() == "" or self.security_answer1.get() == "":
            messagebox.showerror(
                "Error", "All fields are required", parent=self.registration)
        elif self.password1.get() != self.confirmpassword1.get():
            messagebox.showerror(
                "Error", "Both passwords do not match!", parent=self.registration)
        else:
            try:
                con = pymysql.connect(
                    host="localhost", user="root", password="kevin1504", database="Nursery")

                cur = con.cursor()
                cur.execute(
                    "select * from information where Email=%s", self.email1.get())
                row = cur.fetchone()
                cur.execute("insert into information (Fullname, Username, Pass, City, Email, Phone, Question, Answer, UPIID)" "values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                            (self.fullname1.get(),
                             self.username1.get(),
                             self.password1.get(),
                             self.city1.get(),
                             self.email1.get(),
                             self.phnno1.get(),
                             self.security1.get(),
                             self.security_answer1.get(),
                             self.phnno1.get()+"@upi"
                             ))
                con.commit()
                con.close()

                messagebox.showinfo(
                    "Success", "Registered Successfully", parent=self.login)

            except Exception as es:
                messagebox.showerror(
                    "Error", f"Error due to: {str(es)}", parent=self.login)

    # Forgot Password
    def forgot_password(self):
        if self.username1.get() == "":
            messagebox.showerror(
                "Error", "Please enter the username to reset your password", parent=self.login)
        else:
            try:
                con = pymysql.connect(
                    host="localhost", user="root", password="kevin1504", database="Nursery")

                cur = con.cursor()
                cur.execute(
                    "select * from information where Username=%s", self.username1.get())
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror(
                        "Error", "Please enter the valid username to reset the password")
                else:
                    con.close()
                    self.forgot_password = Toplevel()
                    self.forgot_password.title("Forgot Password")
                    self.forgot_password.geometry("400x400+550+150")
                    canvas = Canvas(self.forgot_password, bg="#F5FCA7", height=400,
                                    width=400, bd=0, highlightthickness=0, relief="ridge")
                    canvas.pack()
                    self.forgot_password.focus_force()
                    self.forgot_password.grab_set()
                    self.forgot_password.resizable(False, False)

                    security = Label(canvas, text="Security Question :",
                                     bg="light yellow", font=('Helvetica 12 bold italic'))
                    n = StringVar()
                    self.security1 = ttk.Combobox(
                        canvas, width=32, textvariable=n, state='readonly')
                    self.security1['values'] = (' In what city were you born?',
                                                ' What is your mothers maiden name?',
                                                ' What is the name of your first school? ',
                                                ' What is your astrological sign?')
                    security_answer = Label(canvas, text="Security Answer :",
                                            bg="light yellow", font=('Helvetica 12 bold italic'))
                    self.security_answer1 = Entry(canvas, width=35)
                    new_password = Label(canvas, text="New Password :",
                                         bg="light yellow", font=('Helvetica 12 bold italic'))
                    self.new_password1 = Entry(canvas, width=35)
                    forgot_title = Label(canvas, text="Forgot Password",
                                         bg="light yellow", font=('Helvetica 22 bold'))

                    security.place(x=20, y=80)
                    self.security1.place(x=170, y=80, height=25)
                    security_answer.place(x=25, y=140)
                    self.security_answer1.place(x=170, y=140, height=25)
                    new_password.place(x=30, y=200)
                    self.new_password1.place(x=170, y=200, height=25)
                    forgot_title.place(x=100, y=15)

                    Btn = Button(canvas, text="Reset Password", bg="light yellow", fg="black", font=(
                        'Helvetica 12 bold italic'), command=self.reset_password)
                    Btn.place(x=140, y=280)

                    self.forgot_password.mainloop()

            except Exception as es:
                messagebox.showerror(
                    "Error", f"Error due to: {str(es)}", parent=self.login)
    # Reseting Password

    def reset_password(self):

        if self.security1.get() == "" or self.security_answer1.get() == "" or self.new_password1.get() == "":
            messagebox.showerror(
                "Error", "All fields are required", parent=self.forgot_password)
        else:
            try:
                con = pymysql.connect(
                    host="localhost", user="root", password="kevin1504", database="Nursery")

                cur = con.cursor()
                cur.execute(
                    "select * from information where Username=%s and Question=%s and Answer=%s", (self.username1.get(), self.security1.get(), self.security_answer1.get()))
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror(
                        "Error", "Please enter the correct security details", parent=self.forgot_password)
                else:
                    cur.execute(
                        "update information set Pass=%s where Username=%s", (self.new_password1.get(), self.username1.get()))
                    con.commit()
                    con.close()
                    messagebox.showinfo(
                        "Success", "The password has been reset. Please login with new password.", parent=self.forgot_password)
                    self.reset()
                    self.forgot_password.destroy()

            except Exception as es:
                messagebox.showerror(
                    "Error", f"Error due to: {str(es)}", parent=self.login)

    def reset(self):
        self.security1.current(0)
        self.security_answer1.delete(0, END)
        self.new_password1.delete(0, END)
        self.password1.delete(0, END)
        self.username1.delete(0, END)

    def Home(self):
        home = Tk()
        home.title("Home")
        home.geometry("1000x600+250+100")
        home.configure(bg="#ffffff")

        canvas = Canvas(home, bg="#ffffff", height=600, width=1000,
                        bd=0, highlightthickness=0, relief="ridge")
        canvas.pack()
        background_img = PhotoImage(file=f"Homebg.png")
        canvas.create_image(500.0, 300.0, image=background_img)

        H0 = PhotoImage(file=f"H0.png")
        Hb0 = Button(image=H0, borderwidth=0, highlightthickness=0, relief="flat",
                     command=lambda: [home.destroy(), self.Bonsai()])

        Hb0.place(x=19, y=105, width=295, height=205)

        H1 = PhotoImage(file=f"H1.png")
        Hb1 = Button(image=H1, borderwidth=0, highlightthickness=0,  relief="flat",
                     command=lambda: [home.destroy(), self.Medicinal_Plants()])

        Hb1.place(x=354, y=105, width=295, height=205)

        H2 = PhotoImage(file=f"H2.png")
        Hb2 = Button(image=H2, borderwidth=0, highlightthickness=0,  relief="flat",
                     command=lambda: [home.destroy(), self.Flowering_Plants()])

        Hb2.place(x=689, y=105, width=295, height=205)

        H3 = PhotoImage(file=f"H3.png")
        Hb3 = Button(image=H3, borderwidth=0, highlightthickness=0,  relief="flat",
                     command=lambda: [home.destroy(), self.Terrarium_plants()])

        Hb3.place(x=19, y=354, width=295, height=205)

        H4 = PhotoImage(file=f"H4.png")
        Hb4 = Button(image=H4, borderwidth=0, highlightthickness=0,  relief="flat",
                     command=lambda: [home.destroy(), self.Foliage_plants()])

        Hb4.place(x=354, y=354, width=295, height=205)

        H5 = PhotoImage(file=f"H5.png")
        Hb5 = Button(image=H5, borderwidth=0, highlightthickness=0,  relief="flat",
                     command=lambda: [home.destroy(), self.Succulents()])

        Hb5.place(x=689, y=354, width=295, height=205)

        H6 = PhotoImage(file=f"H6.png")
        Hb6 = Button(image=H6, borderwidth=0,
                     highlightthickness=0,  relief="flat", command=lambda :[home.destroy(), self.Bill()])

        Hb6.place(x=819, y=21, width=50, height=50)

        #H7 = PhotoImage(file=f"H7.png")
        #Hb7 = Button(image=H7, borderwidth=0,highlightthickness=0,  relief="flat")

        #Hb7.place(x=819, y=21, width=50, height=50)

        H8 = PhotoImage(file=f"logout.png")
        Hb8 = Button(image=H8, borderwidth=0, highlightthickness=0, relief="flat",
                     command=lambda: [home.destroy()])

        Hb8.place(x=889, y=21, width=105, height=50)

        home.mainloop()

    def Bonsai(self):
        bonsai = Tk()
        bonsai.title("Bonsai Plants")
        bonsai.geometry("1280x750+100+25")
        bonsai.configure(bg="#ffffff")
        canvas = Canvas(bonsai, bg="#ffffff", height=800,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.pack()

        background_img = PhotoImage(file=f"Bonsaibg.png")
        canvas.create_image(640.0, 400.0, image=background_img)

        img0 = PhotoImage(file=f"cart.png")
        b0 = Button(image=img0, borderwidth=0,
                    highlightthickness=0,  relief="flat", command=lambda :[bonsai.destroy(), self.Bill()])

        b0.place(x=1182, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"back.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0,  relief="flat",
                    command=lambda: [bonsai.destroy(), self.Home()])

        b1.place(x=1106, y=24, width=50, height=50)

        #img2 = PhotoImage(file=f"about.png")
        #b2 = Button(image=img2, borderwidth=0, highlightthickness=0,  relief="flat")

        #b2.place(x=1182, y=24, width=50, height=50)

        img3 = PhotoImage(file=f"view.png")
        b3 = Button(image=img3, borderwidth=0, highlightthickness=0,  relief="flat",
                    command=lambda: [bonsai.destroy(), self.ficus_retusa()])

        b3.place(x=85, y=701, width=146, height=36)

        img4 = PhotoImage(file=f"view.png")
        b4 = Button(image=img4, borderwidth=0, highlightthickness=0,  relief="flat",
                    command=lambda: [bonsai.destroy(), self.pomegranate_bonsai()])

        b4.place(x=405, y=701, width=146, height=36)

        img5 = PhotoImage(file=f"view.png")
        b5 = Button(image=img5, borderwidth=0, highlightthickness=0,  relief="flat",
                    command=lambda: [bonsai.destroy(), self.safari_bonsai()])

        b5.place(x=725, y=701, width=146, height=36)

        img6 = PhotoImage(file=f"view.png")
        b6 = Button(image=img6, borderwidth=0, highlightthickness=0,  relief="flat",
                    command=lambda: [bonsai.destroy(), self.ulmus_bonsai()])

        b6.place(x=1045, y=701, width=146, height=36)

        bonsai.resizable(False, False)
        bonsai.mainloop()

    def ficus_retusa(self):
        ficusretusa = Tk()
        ficusretusa.title("Bonsai Plants")
        ficusretusa.geometry("1280x750+100+25")
        ficusretusa.configure(bg="#ffffff")
        canvas = Canvas(ficusretusa, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"ficusretusabg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [ficusretusa.destroy(), self.Bonsai()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[ficusretusa.destroy(), self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        ficusretusa.resizable(False, False)
        ficusretusa.mainloop()

    def pomegranate_bonsai(self):
        pomegranate = Tk()
        pomegranate.title("Bonsai Plants")
        pomegranate.geometry("1280x750+100+25")
        pomegranate.configure(bg="#ffffff")
        canvas = Canvas(pomegranate, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"pomegranatebg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [pomegranate.destroy(), self.Bonsai()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[pomegranate.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        pomegranate.resizable(False, False)
        pomegranate.mainloop()

    def safari_bonsai(self):
        safari = Tk()
        safari.title("Bonsai Plants")
        safari.geometry("1280x750+100+25")
        safari.configure(bg="#ffffff")
        canvas = Canvas(safari, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"safaribonsaibg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [safari.destroy(), self.Bonsai()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[safari.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        safari.resizable(False, False)
        safari.mainloop()

    def ulmus_bonsai(self):
        ulmus = Tk()
        ulmus.title("Bonsai Plants")
        ulmus.geometry("1280x750+100+25")
        ulmus.configure(bg="#ffffff")
        canvas = Canvas(ulmus, bg="#ffffff", height=750, width=1280,
                        bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"ulmusbonsaibg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [ulmus.destroy(), self.Bonsai()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[ulmus.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        ulmus.resizable(False, False)
        ulmus.mainloop()

    def Medicinal_Plants(self):
        medicinal = Tk()
        medicinal.title("Medicinal Plants")
        medicinal.geometry("1280x750+100+25")
        medicinal.configure(bg="#ffffff")
        canvas = Canvas(medicinal, bg="#ffffff", height=800,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.pack()

        background_img = PhotoImage(file=f"Medbg.png")
        canvas.create_image(640.0, 400.0, image=background_img)

        img0 = PhotoImage(file=f"cart.png")
        b0 = Button(image=img0, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[medicinal.destroy(),self.Bill()])

        b0.place(x=1182, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"back.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [medicinal.destroy(), self.Home()])

        b1.place(x=1106, y=24, width=50, height=50)

        #img2 = PhotoImage(file=f"about.png")
        #b2 = Button(image=img2, borderwidth=0,highlightthickness=0, relief="flat")

        #b2.place(x=1182, y=24, width=50, height=50)

        img3 = PhotoImage(file=f"view.png")
        b3 = Button(image=img3, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[medicinal.destroy(), self.Aloe_Vera()])

        b3.place(x=85, y=701, width=146, height=36)

        img4 = PhotoImage(file=f"view.png")
        b4 = Button(image=img4, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[medicinal.destroy(), self.Rosemary_Plant()])

        b4.place(x=405, y=701, width=146, height=36)

        img5 = PhotoImage(file=f"view.png")
        b5 = Button(image=img5, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[medicinal.destroy(), self.Curry_Plant()])

        b5.place(x=725, y=701, width=146, height=36)

        img6 = PhotoImage(file=f"view.png")
        b6 = Button(image=img6, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[medicinal.destroy(), self.Tulsi_Plant()])

        b6.place(x=1045, y=701, width=146, height=36)

        medicinal.resizable(False, False)
        medicinal.mainloop()

    def Aloe_Vera(self):
        aloevera = Tk()
        aloevera.title("Medicinal Plants")
        aloevera.geometry("1280x750+100+25")
        aloevera.configure(bg="#ffffff")
        canvas = Canvas(aloevera, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"aloeverabg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[aloevera.destroy(), self.Medicinal_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[aloevera.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        aloevera.resizable(False, False)
        aloevera.mainloop()

    def Rosemary_Plant(self):
        rosemary = Tk()
        rosemary.title("Medicinal Plants")
        rosemary.geometry("1280x750+100+25")
        rosemary.configure(bg="#ffffff")
        canvas = Canvas(rosemary, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"rosemarybg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[rosemary.destroy(), self.Medicinal_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[rosemary.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        rosemary.resizable(False, False)
        rosemary.mainloop()

    def Curry_Plant(self):
        curry = Tk()
        curry.title("Medicinal Plants")
        curry.geometry("1280x750+100+25")
        curry.configure(bg="#ffffff")
        canvas = Canvas(curry, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"currybg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[curry.destroy(), self.Medicinal_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[curry.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        curry.resizable(False, False)
        curry.mainloop()
        
    def Tulsi_Plant(self):
        tulsi = Tk()
        tulsi.title("Medicinal Plants")
        tulsi.geometry("1280x750+100+25")
        tulsi.configure(bg="#ffffff")
        canvas = Canvas(tulsi, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"tulsibg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[tulsi.destroy(), self.Medicinal_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[tulsi.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        tulsi.resizable(False, False)
        tulsi.mainloop()

    def Flowering_Plants(self):
        flowering = Tk()
        flowering.title("Flowering Plants")
        flowering.geometry("1280x750+100+25")
        flowering.configure(bg="#ffffff")
        canvas = Canvas(flowering, bg="#ffffff", height=800,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"Floweringbg.png")
        background = canvas.create_image(640.0, 400.0, image=background_img)

        img0 = PhotoImage(file=f"cart.png")
        b0 = Button(image=img0, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[flowering.destroy(),self.Bill()])

        b0.place(x=1182, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"back.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [flowering.destroy(), self.Home()])

        b1.place(x=1106, y=24, width=50, height=50)

        #img2 = PhotoImage(file=f"about.png")
        #b2 = Button(image=img2, borderwidth=0,highlightthickness=0, relief="flat")

        #b2.place(x=1182, y=24, width=50, height=50)

        img3 = PhotoImage(file=f"view.png")
        b3 = Button(image=img3, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[flowering.destroy(), self.Pink_Dwarf()])

        b3.place(x=85, y=701, width=146, height=36)

        img4 = PhotoImage(file=f"view.png")
        b4 = Button(image=img4, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[flowering.destroy(), self.Hibiscus_Plant()])

        b4.place(x=405, y=701, width=146, height=36)

        img5 = PhotoImage(file=f"view.png")
        b5 = Button(image=img5, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[flowering.destroy(), self.Flowery_Carnation()])

        b5.place(x=725, y=701, width=146, height=36)

        img6 = PhotoImage(file=f"view.png")
        b6 = Button(image=img6, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[flowering.destroy(), self.Poinsettia_Plant()])

        b6.place(x=1045, y=701, width=146, height=36)

        flowering.resizable(False, False)
        flowering.mainloop()

    def Pink_Dwarf(self):
        dwarf = Tk()
        dwarf.title("Flowering Plants")
        dwarf.geometry("1280x750+100+25")
        dwarf.configure(bg="#ffffff")
        canvas = Canvas(dwarf, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"ipdbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[dwarf.destroy(), self.Flowering_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[dwarf.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        dwarf.resizable(False, False)
        dwarf.mainloop()

    def Hibiscus_Plant(self):
        hibiscus = Tk()
        hibiscus.title("Flowering Plants")
        hibiscus.geometry("1280x750+100+25")
        hibiscus.configure(bg="#ffffff")
        canvas = Canvas(hibiscus, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"hibiscusbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[hibiscus.destroy(), self.Flowering_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[hibiscus.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        hibiscus.resizable(False, False)
        hibiscus.mainloop()

    def Flowery_Carnation(self):
        carnation = Tk()
        carnation.title("Flowering Plants")
        carnation.geometry("1280x750+100+25")
        carnation.configure(bg="#ffffff")
        canvas = Canvas(carnation, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"carnationbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[carnation.destroy(), self.Flowering_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[carnation.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        carnation.resizable(False, False)
        carnation.mainloop()

    def Poinsettia_Plant(self):
        poinsettia = Tk()
        poinsettia.title("Flowering Plants")
        poinsettia.geometry("1280x750+100+25")
        poinsettia.configure(bg="#ffffff")
        canvas = Canvas(poinsettia, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"poinsettiabg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[poinsettia.destroy(), self.Flowering_Plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[poinsettia.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        poinsettia.resizable(False, False)
        poinsettia.mainloop()
        

    def Terrarium_plants(self):
        terrarium = Tk()
        terrarium.title("Terrarium Plants")
        terrarium.geometry("1280x750+100+25")
        terrarium.configure(bg="#ffffff")
        canvas = Canvas(terrarium, bg="#ffffff", height=800,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"Terrariumbg.png")
        background = canvas.create_image(640.0, 400.0, image=background_img)

        img0 = PhotoImage(file=f"cart.png")
        b0 = Button(image=img0, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[terrarium.destroy(),self.Bill()])

        b0.place(x=1182, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"back.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [terrarium.destroy(), self.Home()])

        b1.place(x=1106, y=24, width=50, height=50)

        #img2 = PhotoImage(file=f"about.png")
        #b2 = Button(image=img2, borderwidth=0,highlightthickness=0, relief="flat")

        #b2.place(x=1182, y=24, width=50, height=50)

        img3 = PhotoImage(file=f"view.png")
        b3 = Button(image=img3, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [terrarium.destroy(), self.profuse_terrarium()])

        b3.place(x=85, y=701, width=146, height=36)

        img4 = PhotoImage(file=f"view.png")
        b4 = Button(image=img4, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [terrarium.destroy(), self.jade_terrarium()])

        b4.place(x=405, y=701, width=146, height=36)

        img5 = PhotoImage(file=f"view.png")
        b5 = Button(image=img5, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [terrarium.destroy(), self.sensveria_milt()])

        b5.place(x=725, y=701, width=146, height=36)

        img6 = PhotoImage(file=f"view.png")
        b6 = Button(image=img6, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [terrarium.destroy(), self.mystic_plant()])

        b6.place(x=1045, y=701, width=146, height=36)

        terrarium.resizable(False, False)
        terrarium.mainloop()

    def profuse_terrarium(self):
        profuse = Tk()
        profuse.geometry("1280x750+100+25")
        profuse.configure(bg="#ffffff")
        canvas = Canvas(profuse, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"profusebg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [profuse.destroy(), self.Terrarium_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[profuse.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        profuse.resizable(False, False)
        profuse.mainloop()

    def jade_terrarium(self):
        jade = Tk()
        jade.geometry("1280x750+100+25")
        jade.configure(bg="#ffffff")
        canvas = Canvas(jade, bg="#ffffff", height=750, width=1280,
                        bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"jadebg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [jade.destroy(), self.Terrarium_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[jade.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        jade.resizable(False, False)
        jade.mainloop()

    def sensveria_milt(self):
        sensveria = Tk()
        sensveria.geometry("1280x750+100+25")
        sensveria.configure(bg="#ffffff")
        canvas = Canvas(sensveria, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"sensveriabg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [sensveria.destroy(), self.Terrarium_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[sensveria.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        sensveria.resizable(False, False)
        sensveria.mainloop()

    def mystic_plant(self):
        mystic = Tk()
        mystic.geometry("1280x750+100+25")
        mystic.configure(bg="#ffffff")
        canvas = Canvas(mystic, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"mysticbg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [mystic.destroy(), self.Terrarium_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[mystic.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        mystic.resizable(False, False)
        mystic.mainloop()

    def Foliage_plants(self):
        foliage = Tk()
        foliage.title("Foliage Plants")
        foliage.geometry("1280x750+100+25")
        foliage.configure(bg="#ffffff")
        canvas = Canvas(foliage, bg="#ffffff", height=800,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"Foliagebg.png")
        background = canvas.create_image(640.0, 400.0, image=background_img)

        img0 = PhotoImage(file=f"cart.png")
        b0 = Button(image=img0, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[foliage.destroy(),self.Bill()])

        b0.place(x=1182, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"back.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [foliage.destroy(), self.Home()])

        b1.place(x=1106, y=24, width=50, height=50)

        #img2 = PhotoImage(file=f"about.png")
        #b2 = Button(image=img2, borderwidth=0,highlightthickness=0, relief="flat")

        #b2.place(x=1182, y=24, width=50, height=50)

        img3 = PhotoImage(file=f"view.png")
        b3 = Button(image=img3, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [foliage.destroy(), self.chinese_banyan()])

        b3.place(x=85, y=701, width=146, height=36)

        img4 = PhotoImage(file=f"view.png")
        b4 = Button(image=img4, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [foliage.destroy(), self.syngonium_plant()])

        b4.place(x=405, y=701, width=146, height=36)

        img5 = PhotoImage(file=f"view.png")
        b5 = Button(image=img5, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [foliage.destroy(), self.araucaria_plant()])

        b5.place(x=725, y=701, width=146, height=36)

        img6 = PhotoImage(file=f"view.png")
        b6 = Button(image=img6, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [foliage.destroy(), self.rubber_plant()])

        b6.place(x=1045, y=701, width=146, height=36)

        foliage.resizable(False, False)
        foliage.mainloop()

    def chinese_banyan(self):
        chinesebanyan = Tk()
        chinesebanyan.geometry("1280x750+100+25")
        chinesebanyan.configure(bg="#ffffff")
        canvas = Canvas(chinesebanyan, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"chinesebanyanbg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [chinesebanyan.destroy(), self.Foliage_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[chinesebanyan.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        chinesebanyan.resizable(False, False)
        chinesebanyan.mainloop()

    def syngonium_plant(self):
        syngonium = Tk()
        syngonium.geometry("1280x750+100+25")
        syngonium.configure(bg="#ffffff")
        canvas = Canvas(syngonium, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"syngoniumplantbg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [syngonium.destroy(), self.Foliage_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[syngonium.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        syngonium.resizable(False, False)
        syngonium.mainloop()

    def araucaria_plant(self):
        araucaria = Tk()
        araucaria.geometry("1280x750+100+25")
        araucaria.configure(bg="#ffffff")
        canvas = Canvas(araucaria, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"araucariabg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [araucaria.destroy(), self.Foliage_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[araucaria.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        araucaria.resizable(False, False)
        araucaria.mainloop()

    def rubber_plant(self):
        rubber = Tk()
        rubber.geometry("1280x750+100+25")
        rubber.configure(bg="#ffffff")
        canvas = Canvas(rubber, bg="#ffffff", height=750,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"rubberbg.png")
        canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [rubber.destroy(), self.Foliage_plants()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[rubber.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        rubber.resizable(False, False)
        rubber.mainloop()

    def Succulents(self):
        succulents = Tk()
        succulents.title("Succulents Plants")
        succulents.geometry("1280x750+100+25")
        succulents.configure(bg="#ffffff")
        canvas = Canvas(succulents, bg="#ffffff", height=800,
                        width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"Succulentsbg.png")
        background = canvas.create_image(640.0, 400.0, image=background_img)

        img0 = PhotoImage(file=f"cart.png")
        b0 = Button(image=img0, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[succulents.destroy(),self.Bill()])

        b0.place(x=1182, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"back.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda: [succulents.destroy(), self.Home()])

        b1.place(x=1106, y=24, width=50, height=50)

        #img2 = PhotoImage(file=f"about.png")
        #b2 = Button(image=img2, borderwidth=0,highlightthickness=0, relief="flat")

        #b2.place(x=1182, y=24, width=50, height=50)

        img3 = PhotoImage(file=f"view.png")
        b3 = Button(image=img3, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[succulents.destroy(), self.Cryptanthus_Plant()])

        b3.place(x=85, y=701, width=146, height=36)

        img4 = PhotoImage(file=f"view.png")
        b4 = Button(image=img4, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[succulents.destroy(), self.Haworthia_Plant()])

        b4.place(x=405, y=701, width=146, height=36)

        img5 = PhotoImage(file=f"view.png")
        b5 = Button(image=img5, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[succulents.destroy(), self.Moon_Cactus()])

        b5.place(x=725, y=701, width=146, height=36)

        img6 = PhotoImage(file=f"view.png")
        b6 = Button(image=img6, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[succulents.destroy(), self.Mamm_Cactus()])

        b6.place(x=1045, y=701, width=146, height=36)

        succulents.resizable(False, False)
        succulents.mainloop()

    def Cryptanthus_Plant(self):
        cryp = Tk()
        cryp.title("Cactus & Succulents")
        cryp.geometry("1280x750+100+25")
        cryp.configure(bg="#ffffff")
        canvas = Canvas(cryp, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"crypbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[cryp.destroy(), self.Succulents()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[cryp.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        cryp.resizable(False, False)
        cryp.mainloop()

    def Haworthia_Plant(self):
        haworthia = Tk()
        haworthia.title("Cactus & Succulents")
        haworthia.geometry("1280x750+100+25")
        haworthia.configure(bg="#ffffff")
        canvas = Canvas(haworthia, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"hawbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[haworthia.destroy(), self.Succulents()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[haworthia.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        haworthia.resizable(False, False)
        haworthia.mainloop()

    def Moon_Cactus(self):
        moon = Tk()
        moon.title("Cactus & Succulents")
        moon.geometry("1280x750+100+25")
        moon.configure(bg="#ffffff")
        canvas = Canvas(moon, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"mooncactusbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[moon.destroy(), self.Succulents()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[moon.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        moon.resizable(False, False)
        moon.mainloop()

    def Mamm_Cactus(self):
        mamm = Tk()
        mamm.title("Cactus & Succulents")
        mamm.geometry("1280x750+100+25")
        mamm.configure(bg="#ffffff")
        canvas = Canvas(mamm, bg="#ffffff", height=750, width=1280, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"mammbg.png")
        background = canvas.create_image(640.0, 375.0, image=background_img)

        img0 = PhotoImage(file=f"back.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[mamm.destroy(), self.Succulents()])

        b0.place(x=1106, y=24, width=50, height=50)

        img1 = PhotoImage(file=f"cart.png")
        b1 = Button(image=img1, borderwidth=0,
                    highlightthickness=0, relief="flat", command=lambda :[mamm.destroy(),self.Bill()])

        b1.place(x=1182, y=24, width=50, height=50)

        mamm.resizable(False, False)
        mamm.mainloop()

    #Billing System
    def Bill(self):
        bill = Tk()
        bill.title("Cart")
        bill.geometry("1250x600+150+100")
        bill.configure(bg="light yellow")

        # function to calculate the
        # price of all the orders
        def calculate():
            global total
            # dic for storing the
            # food quantity and price
            dic = {'Ficus Retusa': [e1, 1199], 'Pomegranate Bonsai': [e2, 1399], 'Safari Bonsai': [e3, 2149],
                   'Ulmus Bonsai': [e4, 1499], 'Aloe Vera': [e5, 549], 'Rosemary Plant': [e6, 399],
                   'Curry Plant': [e7, 499], 'Tulsi Plant': [e8, 449], 'Ixora Pink Dwarf': [e9, 649],
                   'Hibiscus Plant': [e10, 549], 'Flowery Carnation': [e11, 549], 'Poinsettia Plant': [e12, 1649],
                   'Profuse Terrarium': [e13, 549], 'Jade Terrarium': [e14, 849], 'Sensveria Milt': [e15, 849],
                   'Mystic Money Plant': [e16, 549], 'Chinese Banyan': [e17, 1749], 'Syngonium Plant': [e18, 549],
                   'Araucaria Plant': [e19, 599], 'Rubber Plant': [e20, 699], 'Cryptanthus Plant': [e21, 499],
                   'Haworthia Plant': [e22, 599], 'Moon Cactus Plant':[e23, 649], 'Mammillaria Cactus': [e24, 3499]}
            total = 0
            for key, val in dic.items():
                if val[0].get() != "":
                    total += int(val[0].get()) * val[1]

            label1 = Label(bill, text="Total Amount - " + str(total), font="times 18", bg='light yellow')

            # position it
            label1.place(x=450, y=530)
            label1.after(1000, label1.destroy)
            bill.after(1000, calculate)

        label2 = Label(bill, text="Cart", font="Helvetica 18 bold italic", bg='light yellow')
        label2.place(x=625, y=20, anchor="center")

        label3 = Label(bill, text="Bonsai  Plants:", font="Helvetica 16 bold italic", bg='light yellow')
        label3.place(x=20, y=50)

        label4 = Label(bill, text="Ficus Retusa (Rs 1199/-):", font="Helvetica 14 italic", bg='light yellow')
        label4.place(x=20, y=90)
        e1 = ttk.Combobox(bill, width=2, state='readonly')
        e1['values'] = ('0','1', '2', '3', '4', '5')
        e1.place(x=250, y=94)

        label5 = Label(bill, text="Pomegranate Bonsai (Rs 1399/-):", font="Helvetica 14 italic", bg='light yellow')
        label5.place(x=20, y=130)
        e2 = ttk.Combobox(bill, width=2, state='readonly')
        e2['values'] = ('0','1', '2', '3', '4', '5')
        e2.place(x=320, y=134)

        label6 = Label(bill, text="Safari Bonsai (Rs 2149/-):", font="Helvetica 14 italic", bg='light yellow')
        label6.place(x=20, y=170)
        e3 = ttk.Combobox(bill, width=2, state='readonly')
        e3['values'] = ('0','1', '2', '3', '4', '5')
        e3.place(x=250, y=174)

        label7 = Label(bill, text="Ulmus Bonsai (Rs 1499/-):", font="Helvetica 14 italic", bg='light yellow')
        label7.place(x=20, y=210)
        e4 = ttk.Combobox(bill, width=2, state='readonly')
        e4['values'] = ('0','1', '2', '3', '4', '5')
        e4.place(x=260, y=214)

        label8 = Label(bill, text="Medicinal Plants:", font="Helvetica 16 bold italic", bg='light yellow')
        label8.place(x=480, y=50)

        label9 = Label(bill, text="Aloe Vera (Rs 549/-):", font="Helvetica 14 italic", bg='light yellow')
        label9.place(x=480, y=90)
        e5 = ttk.Combobox(bill, width=2, state='readonly')
        e5['values'] = ('0','1', '2', '3', '4', '5')
        e5.place(x=670, y=94)

        label10 = Label(bill, text="Rosemary Plant (Rs 399/-):", font="Helvetica 14 italic", bg='light yellow')
        label10.place(x=480, y=130)
        e6 = ttk.Combobox(bill, width=2, state='readonly')
        e6['values'] = ('0','1', '2', '3', '4', '5')
        e6.place(x=725, y=134)

        label11 = Label(bill, text="Curry Plant (Rs 449/-):", font="Helvetica 14 italic", bg='light yellow')
        label11.place(x=480, y=170)
        e7 = ttk.Combobox(bill, width=2, state='readonly')
        e7['values'] = ('0','1', '2', '3', '4', '5')
        e7.place(x=680, y=174)

        label12 = Label(bill, text="Tulsi Plant (Rs 449/-):", font="Helvetica 14 italic", bg='light yellow')
        label12.place(x=480, y=210)
        e8 = ttk.Combobox(bill, width=2, state='readonly')
        e8['values'] = ('0','1', '2', '3', '4', '5')
        e8.place(x=680, y=214)

        label13 = Label(bill, text="Flowering Plants:", font="Helvetica 16 bold italic", bg='light yellow')
        label13.place(x=880, y=50)

        label14 = Label(bill, text="Ixora Pink Dwarf (Rs 649/-):", font="Helvetica 14 italic", bg='light yellow')
        label14.place(x=880, y=90)
        e9 = ttk.Combobox(bill, width=2, state='readonly')
        e9['values'] = ('0','1', '2', '3', '4', '5')
        e9.place(x=1125, y=94)

        label15 = Label(bill, text="Hibiscus Plant (Rs 549/-):", font="Helvetica 14 italic", bg='light yellow')
        label15.place(x=880, y=130)
        e10 = ttk.Combobox(bill, width=2, state='readonly')
        e10['values'] = ('0','1', '2', '3', '4', '5')
        e10.place(x=1110, y=134)

        label16 = Label(bill, text="Flowery Carnation (Rs 549/-):", font="Helvetica 14 italic", bg='light yellow')
        label16.place(x=880, y=170)
        e11 = ttk.Combobox(bill, width=2, state='readonly')
        e11['values'] = ('0','1', '2', '3', '4', '5')
        e11.place(x=1140, y=174)

        label17 = Label(bill, text="Poinsettia Plant (Rs 1649/-):", font="Helvetica 14 italic", bg='light yellow')
        label17.place(x=880, y=210)
        e12 = ttk.Combobox(bill, width=2, state='readonly')
        e12['values'] = ('0','1', '2', '3', '4', '5')
        e12.place(x=1135, y=214)

        label18 = Label(bill, text="Terrarium Plants:", font="Helvetica 16 bold italic", bg='light yellow')
        label18.place(x=20, y=300)

        label19 = Label(bill, text="Profuse Terrarium (Rs 549/-):", font="Helvetica 14 italic", bg='light yellow')
        label19.place(x=20, y=340)
        e13 = ttk.Combobox(bill, width=2, state='readonly')
        e13['values'] = ('0','1', '2', '3', '4', '5')
        e13.place(x=280, y=344)

        label20 = Label(bill, text="Jade Terrarium (Rs 849/-):", font="Helvetica 14 italic", bg='light yellow')
        label20.place(x=20, y=380)
        e14 = ttk.Combobox(bill, width=2, state='readonly')
        e14['values'] = ('0','1', '2', '3', '4', '5')
        e14.place(x=260, y=384)

        label21 = Label(bill, text="Sensveria Milt (Rs 849/-):", font="Helvetica 14 italic", bg='light yellow')
        label21.place(x=20, y=420)
        e15 = ttk.Combobox(bill, width=2, state='readonly')
        e15['values'] = ('0','1', '2', '3', '4', '5')
        e15.place(x=250, y=424)

        label22 = Label(bill, text="Mystic Money Plant (Rs 549/-):", font="Helvetica 14 italic", bg='light yellow')
        label22.place(x=20, y=460)
        e16 = ttk.Combobox(bill, width=2, state='readonly')
        e16['values'] = ('0','1', '2', '3', '4', '5')
        e16.place(x=295, y=464)

        label23 = Label(bill, text="Foliage Plants:", font="Helvetica 16 bold italic", bg='light yellow')
        label23.place(x=480, y=300)

        label24 = Label(bill, text="Chinese Banyan (Rs 1749/-):", font="Helvetica 14 italic", bg='light yellow')
        label24.place(x=480, y=340)
        e17 = ttk.Combobox(bill, width=2, state='readonly')
        e17['values'] = ('0', '1', '2', '3', '4', '5')
        e17.place(x=740, y=344)

        label25 = Label(bill, text="Syngonium Plant (Rs 549/-):", font="Helvetica 14 italic", bg='light yellow')
        label25.place(x=480, y=380)
        e18 = ttk.Combobox(bill, width=2, state='readonly')
        e18['values'] = ('0', '1', '2', '3', '4', '5')
        e18.place(x=735, y=384)

        label26 = Label(bill, text="Araucaria Plant (Rs 449/-):", font="Helvetica 14 italic", bg='light yellow')
        label26.place(x=480, y=420)
        e19 = ttk.Combobox(bill, width=2, state='readonly')
        e19['values'] = ('0', '1', '2', '3', '4', '5')
        e19.place(x=715, y=424)

        label27 = Label(bill, text="Rubber Plant (Rs 699/-):", font="Helvetica 14 italic", bg='light yellow')
        label27.place(x=480, y=460)
        e20 = ttk.Combobox(bill, width=2, state='readonly')
        e20['values'] = ('0', '1', '2', '3', '4', '5')
        e20.place(x=695, y=464)

        label28 = Label(bill, text="Succulent Plants:", font="Helvetica 16 bold italic", bg='light yellow')
        label28.place(x=880, y=300)

        label29 = Label(bill, text="Cryptanthus Plant (Rs 499/-):", font="Helvetica 14 italic", bg='light yellow')
        label29.place(x=880, y=340)
        e21 = ttk.Combobox(bill, width=2, state='readonly')
        e21['values'] = ('0', '1', '2', '3', '4', '5')
        e21.place(x=1140, y=344)

        label30 = Label(bill, text="Haworthia Plant (Rs 599/-):", font="Helvetica 14 italic", bg='light yellow')
        label30.place(x=880, y=380)
        e22 = ttk.Combobox(bill, width=2, state='readonly')
        e22['values'] = ('0', '1', '2', '3', '4', '5')
        e22.place(x=1125, y=384)

        label31 = Label(bill, text="Moon Cactus Plant (Rs 649/-):", font="Helvetica 14 italic", bg='light yellow')
        label31.place(x=880, y=420)
        e23 = ttk.Combobox(bill, width=2, state='readonly')
        e23['values'] = ('0', '1', '2', '3', '4', '5')
        e23.place(x=1150, y=424)

        label32 = Label(bill, text="Mammillaria Schwarzii (Rs 3499/-):", font="Helvetica 14 italic", bg='light yellow')
        label32.place(x=880, y=460)
        e24 = ttk.Combobox(bill, width=2, state='readonly')
        e24['values'] = ('0', '1', '2', '3', '4', '5')
        e24.place(x=1195, y=464)


        b1 = Button(bill, text="Checkout", font="Helvetica 16 bold italic", bg="light yellow",
                    command=lambda: [bill.destroy(),self.Payment_Portal()])
        b1.place(x=800, y=520)

        img0 = PhotoImage(file=f"arrow.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0,
                    command=lambda: [bill.destroy(), self.Home()])
        b0.place(x=1100, y=10)

        # execute calculate function after 1 second
        bill.after(1000, calculate)

        # closing the main loop
        bill.mainloop()

    def Payment_Portal(self):
        payment = Tk()
        payment.title("Payment Portal")
        payment.geometry("800x500+350+120")
        payment.configure(bg="#ffffff")
        canvas = Canvas(payment, bg="#ffffff", height=500, width=800, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"paymentbg.png")
        background = canvas.create_image(400.0, 250.0, image=background_img)

        img0 = PhotoImage(file=f"visaimg.png")
        b0 = Button(image=img0, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[payment.destroy(), self.Visa_Payment()])

        b0.place(x=487, y=159, width=159, height=44)

        img1 = PhotoImage(file=f"netbankingimg.png")
        b1 = Button(image=img1, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[payment.destroy(), self.NetBanking1()])

        b1.place(x=487, y=259, width=159, height=44)

        img2 = PhotoImage(file=f"upiimg.png")
        b2 = Button(image=img2, borderwidth=0, highlightthickness=0, relief="flat",
                    command=lambda :[payment.destroy(), self.UPI()])

        b2.place(x=487, y=360, width=159, height=47)

        b3 = Button(canvas, text="Back", command=lambda: [payment.destroy(), self.Bill()],
                    font="Helvetica 16 bold italic", fg="black",
                    bg="grey").place(x=20, y=30)

        label = Label(payment, text="Total amount to be paid: " + str(total), font="Helvetica 16 bold italic",
                      fg="black", bg="grey")
        label.place(x=257, y=450)

        payment.resizable(False, False)
        payment.mainloop()



    def Visa_Payment(self):
        self.visa = Tk()
        self.visa.title("Visa Payment")
        self.visa.configure(bg="#ffffff")
        self.visa.geometry("600x500+450+150")
        self.visa.resizable(False, False)
        canvas = Canvas(self.visa,bg="#ffffff", height=500, width=600, bd=0, highlightthickness=0, relief="ridge")
        canvas.place(x=0, y=0)

        background_img = PhotoImage(file=f"portalbg.png")
        background = canvas.create_image(400.0, 250.0, image=background_img)


        lbl_cardnumber = Label(canvas, text="Card Number", font="Helvetica 16 bold italic", fg="black", bg="grey"
                              ).place(x=100, y=100)
        self.cardnumber = Entry(canvas, font=("Goudy old style", 15), bg="white")
        self.cardnumber.place(x=100, y=150, width=300, height=33)

        lbl_Expiredate = Label(canvas, text="Expire Date", font="Helvetica 16 bold italic", fg="black", bg="grey"
                              ).place(x=100, y=200)

        list1 = ["MM", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
        self.cmb = ttk.Combobox(canvas, value=list1, width=80, height=50, state="readonly")
        self.cmb.place(x=100, y=250, width=70, height=35)
        self.cmb.current(0)

        list2 = ["YY", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030"]
        self.cmb1 = ttk.Combobox(canvas, value=list2, width=80, height=50, state="readonly")
        self.cmb1.place(x=200, y=250, width=70, height=35)
        self.cmb1.current(0)

        lbl_cvv = Label(canvas, text="CVV", font="Helvetica 16 bold italic", fg="black",bg="grey").place(x=400, y=200)
        
        self.cvv = Entry(canvas, font="Helvetica 16 bold italic", show="*", bg="white")
        self.cvv.place(x=400, y=250, width=100, height=33)

        b1 = Button(canvas, text="Pay", font="Helvetica 16 bold italic", fg="black", bg="grey",command=lambda :[self.validate()]).place(x=350, y=380, width=150,  height=40)

        b2 = Button(canvas, text="Back", command=lambda :[self.visa.destroy(),self.Payment_Portal()], font="Helvetica 16 bold italic", fg="black",
                    bg="grey").place(x=100, y=380, width=150, height=40)

        self.visa.mainloop()

    def validate(self):
        if self.cardnumber.get() == "" or self.cmb.get() == ""  or self.cmb1.get() == ""  or self.cvv.get() == "":
            messagebox.showerror("Error", "All fields are required!", parent=self.visa)

        else:
            messagebox.showinfo("Message", "Transaction was successfull!")
            self.visa.destroy()
            self.Home()


        
    def NetBanking1(self):
        net = Tk()
        net.title("Netbanking Payment")
        net.geometry("600x500+450+150")
        net.resizable(False, False)

        canvas = Canvas(net, bg="grey")
        canvas.place(x=0, y=0, width=600, height=500)

        background_img = PhotoImage(file=f"portalbg.png")
        background = canvas.create_image(400.0, 250.0, image=background_img)

        lbl1 = Label(canvas, text="Choose a bank to proceed:", font="Helvetica 18 bold italic", fg="black",
                     bg="grey").place(x=160, y=10)
        b1 = Button(canvas, text="Axis Bank", command=lambda :[net.destroy(),self.NetBanking2()], font="Helvetica 16 bold italic",
                    fg="black", bg="grey").place(x=160, y=80)
        b2 = Button(canvas, text="HDFC Bank", command=lambda :[net.destroy(),self.NetBanking2()], font="Helvetica 16 bold italic",
                    fg="black", bg="grey").place(x=160, y=160)
        b3 = Button(canvas, text="SBI", command=lambda :[net.destroy(),self.NetBanking2()], font="Helvetica 16 bold italic",
                    fg="black", bg="grey").place(x=160, y=240)
        b4 = Button(canvas, text="ICICI BANK",  command=lambda :[net.destroy(),self.NetBanking2()], font="Helvetica 16 bold italic",
                    fg="black", bg="grey").place(x=160, y=320)
        b5 = Button(canvas, text="Kotak Mahindra Bank", command=lambda :[net.destroy(),self.NetBanking2()],font="Helvetica 16 bold italic",
                    fg="black", bg="grey").place(x=160, y=400)
        b6 = Button(canvas, text="Back", font="Helvetica 16 bold italic", fg="black",
                    bg="grey", command=lambda :[net.destroy(), self.Payment_Portal()]).place(x=20, y=10)

        net.mainloop()

    def NetBanking2(self):
        self.net = Tk()
        self.net.title("Netbanking Payment")
        self.net.geometry("600x500+450+150")
        self.net.resizable(False, False)

        canvas = Canvas(self.net, bg="grey")
        canvas.place(x=0, y=0, width=600, height=500)

        background_img = PhotoImage(file=f"portalbg.png")
        background = canvas.create_image(400.0, 250.0, image=background_img)

        lbl_username = Label(canvas, text="Username", font="Helvetica 16 bold italic", fg="black",
                             bg="grey").place(x=100, y=100)
        self.username = Entry(canvas, font="Helvetica 16 bold italic", bg="white")
        self.username.place(x=100, y=150, width=300, height=33)

        lbl_password = Label(canvas, text="Password", font="Helvetica 16 bold italic", fg="black",
                             bg="grey").place(x=100, y=200)
        self.password = Entry(canvas, font="Helvetica 16 bold italic", show="*", bg="white")
        self.password.place(x=100, y=250, width=300, height=33)

        b1 = Button(canvas, text="Pay", font="Helvetica 16 bold italic", fg="black", bg="grey",
                    command=lambda :[self.check_function()]).place(x=350,y=380,  width=150,height=40)
        b2 = Button(canvas, text="Back", font="Helvetica 16 bold italic", fg="black",
                    bg="grey", command=lambda :[self.net.destroy(), self.NetBanking1()]).place(x=100, y=380, width=150, height=40)
        
        self.net.mainloop()

    def check_function(self):
        if self.username.get() == "" or self.password.get() == "":
            messagebox.showerror(
                "Error", "All fields are required!", parent=self.net)
        elif self.username.get() == self.password.get():
            messagebox.showerror(
                "Error", "Username and Password should not be the same!", parent=self.net)
        else:
            try:
                con = pymysql.connect(
                    host="localhost", user="root", password="kevin1504", database="Nursery")

                cur = con.cursor()
                cur.execute('select * from information where Username=%s and Pass=%s',
                            (self.username.get(), self.password.get()))

                row = cur.fetchone()
                if row == None:
                    messagebox.showerror(
                        'Error', 'Invalid Username or Password', parent=self.net)

                else:
                    messagebox.showinfo("Message", "Transaction was successfull!")
                    self.net.destroy()
                    self.Home()

                con.close()

            except Exception as es:
                messagebox.showerror(
                    "Error", f"Error due to: {str(es)}", parent=self.net)
                
    def UPI(self):
        self.upi = Tk()
        self.upi.title("UPI Payment")
        self.upi.geometry("600x500+450+150")
        self.upi.resizable(False, False)

        canvas = Canvas(self.upi,bg="grey")
        canvas.place(x=0, y=0, width=900, height=900)

        background_img = PhotoImage(file=f"portalbg.png")
        background = canvas.create_image(400.0, 250.0, image=background_img)

        lbl_UPIID = Label(canvas, text="UPI ID", font="Helvetica 16 bold italic", fg="black",bg="grey").place(
            x=100, y=100)
        self.UPIID = Entry(canvas, font=("Goudy old style", 15), bg="white")
        self.UPIID.place(x=100, y=150, width=300, height=33)

        lbl_password = Label(canvas, text="Password", font="Helvetica 16 bold italic", fg="black",
                            bg="grey").place(x=100, y=200)
        self.password = Entry(canvas, font="Helvetica 16 bold italic",show="*", bg="white")
        self.password.place(x=100, y=250, width=300, height=33)

        b1 = Button(canvas, text="Pay", font="Helvetica 16 bold italic", fg="black",
                    bg="grey", command=lambda :[self.btn_clicked()]).place(x=350, y=380, width=150, height=40)
        b2 = Button(canvas, text="Back", command=lambda :[self.upi.destroy(), self.Payment_Portal()], font="Helvetica 16 bold italic", fg="black",
                    bg="grey").place(x=100, y=380, width=150, height=40)

        self.upi.mainloop()

    def btn_clicked(self):
        if self.UPIID.get() == "" or self.password.get() == "":
            messagebox.showerror("Error", "All fields are required!", parent=self.upi)
        elif self.UPIID.get() == self.password.get():
            messagebox.showerror("Error", "Username and Password should not be the same!", parent=self.upi)
        else:
            try:
                con = pymysql.connect(
                    host="localhost", user="root", password="kevin1504", database="Nursery")

                cur = con.cursor()
                cur.execute('select * from information where UPIID=%s and Pass=%s',
                            (self.UPIID.get(), self.password.get()))

                row = cur.fetchone()
                if row == None:
                    messagebox.showerror(
                        'Error', 'Invalid UPIID or Password', parent=self.upi)

                else:
                    messagebox.showinfo("Message", "Transaction was successfull!")
                    self.upi.destroy()
                    self.Home()

                con.close()
            except Exception as es:
                messagebox.showerror(
                    "Error", f"Error due to: {str(es)}", parent=self.upi)




root = Tk()
obj = Login()
root.mainloop()
